# JS-1-exercises
tema 5 indledende øvelser
